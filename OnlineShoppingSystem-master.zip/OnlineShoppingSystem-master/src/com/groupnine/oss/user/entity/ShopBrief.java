package com.groupnine.oss.user.entity;

public class ShopBrief {
    public String shopName;
    public String shopId;

    public void setShopName(String name) {
        this.shopName = name;
    }

    public void setShopId(String id) {
        this.shopId = id;
    }
}
