package com.groupnine.oss.user.entity;

/*
 * com.groupnine.oss.user.entity.Receiver 属性名字不符合要求
 */

public class OrderReceiver {
    public String name;
    public String address;
    public String phone;
}
