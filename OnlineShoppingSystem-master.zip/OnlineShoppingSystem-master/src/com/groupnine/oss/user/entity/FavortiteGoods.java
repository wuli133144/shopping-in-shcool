package com.groupnine.oss.user.entity;

public class FavortiteGoods {
    public String goodsId;
    public String goodsName;
    public String goodsDescribe;
    public String imageAddr;
    public String sales;
    public String price;
}
