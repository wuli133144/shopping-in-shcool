package com.groupnine.oss.user.entity;

public class FavoriteShop {
    public String shopId;
    public String shopName;
}
