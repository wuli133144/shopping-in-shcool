package com.groupnine.oss.user.entity;

import java.util.List;

public class SCOrder {
    public String shopId;
    public String annotation;
    public List<String> id;
}
