package com.groupnine.oss.user.entity;

public final class FalseResult {
    private String result = "false";
}
