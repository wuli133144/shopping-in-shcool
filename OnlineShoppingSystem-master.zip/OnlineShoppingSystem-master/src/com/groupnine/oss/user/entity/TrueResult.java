package com.groupnine.oss.user.entity;

public final class TrueResult {
    private String result = "true";
}
