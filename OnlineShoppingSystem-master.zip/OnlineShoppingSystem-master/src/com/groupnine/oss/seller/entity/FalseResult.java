package com.groupnine.oss.seller.entity;

public class FalseResult {
    public String result = "false";
}
