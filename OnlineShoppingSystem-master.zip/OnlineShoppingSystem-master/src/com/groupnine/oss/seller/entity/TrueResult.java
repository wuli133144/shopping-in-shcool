package com.groupnine.oss.seller.entity;

public class TrueResult {
    public String result = "true";
}
